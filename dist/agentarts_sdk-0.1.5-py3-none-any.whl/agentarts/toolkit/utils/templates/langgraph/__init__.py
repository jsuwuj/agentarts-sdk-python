"""LangGraph Agent Template"""
