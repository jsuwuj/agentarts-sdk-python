"""LangChain Agent Template"""
