"""Google ADK templates"""
