"""Basic Agent Template"""
