"""Config operation implementation"""

import platform as platform_module
from pathlib import Path

from rich.console import Console
from rich.table import Table

from agentarts.toolkit.utils.runtime.config import (
    AgentArtsConfig,
    AgentArtsConfigList,
    BaseConfig,
    SWRConfig,
    detect_arch,
)
from agentarts.toolkit.utils.swr_org import generate_swr_org_name

console = Console()

CONFIG_FILE_NAME = ".agentarts_config.yaml"


def detect_platform() -> str:
    """
    Detect the current platform architecture.

    Returns:
        str: Platform string (e.g., 'linux/amd64', 'linux/arm64')
    """
    machine = platform_module.machine().lower()
    system = platform_module.system().lower()

    if system in {"linux", "darwin"}:
        if machine in ("aarch64", "arm64"):
            return "linux/arm64"
        if machine in ("x86_64", "amd64"):
            return "linux/amd64"
    elif system == "windows":
        if machine in ("amd64", "x86_64"):
            return "linux/amd64"
        if machine in ("arm64", "aarch64"):
            return "linux/arm64"

    # Unknown architecture: default to linux/arm64 (the backend is
    # predominantly arm).
    return "linux/arm64"


def detect_dependency_file() -> str:
    """
    Detect dependency file in current directory.

    Priority: requirements.txt > pyproject.toml

    Returns:
        Detected dependency file name or 'requirements.txt' as default
    """
    cwd = Path.cwd()

    if (cwd / "requirements.txt").exists():
        return "requirements.txt"

    if (cwd / "pyproject.toml").exists():
        return "pyproject.toml"

    return "requirements.txt"


def get_config_file_path() -> Path:
    """Get the configuration file path in current directory."""
    return Path.cwd() / CONFIG_FILE_NAME


def load_config() -> AgentArtsConfigList:
    """
    Load configuration from .agentarts_config.yaml.

    Returns:
        AgentArtsConfigList instance (empty if file doesn't exist)
    """
    config_path = get_config_file_path()
    if config_path.exists():
        try:
            return AgentArtsConfigList.from_yaml(str(config_path))
        except Exception as e:
            console.print(f"[yellow]Warning: Failed to load config file: {e}[/yellow]")
            return AgentArtsConfigList()
    return AgentArtsConfigList()


def save_config(config: AgentArtsConfigList) -> bool:
    """
    Save configuration to .agentarts_config.yaml.

    Args:
        config: AgentArtsConfigList instance to save

    Returns:
        True if successful, False otherwise
    """
    config_path = get_config_file_path()
    try:
        config.to_yaml(str(config_path))
        return True
    except Exception as e:
        console.print(f"[red]Error: Failed to save config file: {e}[/red]")
        return False


def ensure_config_exists() -> AgentArtsConfigList:
    """
    Ensure configuration file exists and return config.

    Returns:
        AgentArtsConfigList instance
    """
    config = load_config()
    if not get_config_file_path().exists():
        save_config(config)
    return config


def list_agents() -> list[str]:
    """
    List all configured agents.

    Returns:
        List of agent names
    """
    config = load_config()
    return config.list_agents()


def get_default_agent() -> str | None:
    """
    Get the default agent name.

    Returns:
        Default agent name or None
    """
    config = load_config()
    return config.default_agent


def set_default_agent(name: str) -> bool:
    """
    Set the default agent name.

    Args:
        name: Agent name to set as default

    Returns:
        True if successful, False if agent not found
    """
    config = load_config()

    if name not in config.agents:
        console.print(f"[red]Error: Agent '{name}' not found in configuration[/red]")
        console.print(f"[dim]Available agents: {', '.join(config.list_agents()) or 'none'}[/dim]")
        return False

    config.default_agent = name
    if save_config(config):
        console.print(f"[green]Done:[/green] Default agent set to [cyan]{name}[/cyan]")
        return True
    return False


def get_agent(name: str | None = None) -> AgentArtsConfig | None:
    """
    Get agent configuration by name.

    Args:
        name: Agent name (uses default if None)

    Returns:
        AgentArtsConfig if found, None otherwise
    """
    config = load_config()
    return config.get_agent(name)


def add_agent(
    name: str,
    entrypoint: str,
    region: str | None = None,
    swr_organization: str | None = None,
    swr_repository: str | None = None,
    dependency_file: str | None = None,
    set_as_default: bool = True,
    organization_auto_create: bool = False,
    repository_auto_create: bool = False,
) -> bool:
    """
    Add or update an agent configuration.

    Args:
        name: Agent name
        entrypoint: Agent entrypoint
        region: Huawei Cloud region
        swr_organization: SWR organization
        swr_repository: SWR repository
        dependency_file: Path to dependency file (e.g., requirements.txt)
        set_as_default: Whether to set as default agent
        organization_auto_create: Whether to auto-create SWR organization
        repository_auto_create: Whether to auto-create SWR repository

    Returns:
        True if successful
    """
    config = load_config()

    existing_agent = config.get_agent(name)

    if existing_agent:
        existing_dict = existing_agent.to_dict()

        if entrypoint is not None:
            existing_dict.setdefault("base", {})["entrypoint"] = entrypoint
        if region is not None:
            existing_dict.setdefault("base", {})["region"] = region
        if dependency_file is not None:
            existing_dict.setdefault("base", {})["dependency_file"] = dependency_file
        existing_dict.setdefault("base", {})["name"] = name

        if swr_organization is not None:
            existing_dict.setdefault("swr_config", {})["organization"] = swr_organization
        if swr_repository is not None:
            existing_dict.setdefault("swr_config", {})["repository"] = swr_repository
        existing_dict.setdefault("swr_config", {})["organization_auto_create"] = organization_auto_create
        existing_dict.setdefault("swr_config", {})["repository_auto_create"] = repository_auto_create

        agent_config = AgentArtsConfig.from_dict(existing_dict)
    else:
        detected_platform = detect_platform()
        detected_arch = detect_arch()
        agent_config = AgentArtsConfig(
            base=BaseConfig(
                name=name,
                entrypoint=entrypoint,
                region=region,
                dependency_file=dependency_file,
                platform=detected_platform,
                arch=detected_arch,
            ),
            swr_config=SWRConfig(
                organization=swr_organization,
                repository=swr_repository,
                organization_auto_create=organization_auto_create,
                repository_auto_create=repository_auto_create,
            ),
        )

        final_region = region or "cn-southwest-2"
        final_org = swr_organization or generate_swr_org_name(region=final_region)
        final_repo = swr_repository or f"agent_{name}"

        agent_config_dict = agent_config.to_dict()
        agent_config = AgentArtsConfig.from_dict(agent_config_dict)

    config.add_agent(name, agent_config)

    if set_as_default or config.default_agent is None:
        config.default_agent = name

    if save_config(config):
        console.print(f"[green]Done:[/green] Agent [cyan]{name}[/cyan] configured successfully")
        console.print(f"[dim]Config file: {get_config_file_path()}[/dim]")
        return True
    return False


def remove_agent(name: str) -> bool:
    """
    Remove an agent configuration.

    Args:
        name: Agent name

    Returns:
        True if successful, False if agent not found
    """
    config = load_config()

    if name not in config.agents:
        console.print(f"[red]Error: Agent '{name}' not found in configuration[/red]")
        return False

    config.remove_agent(name)
    if save_config(config):
        console.print(f"[green]Done:[/green] Agent [cyan]{name}[/cyan] removed")
        return True
    return False


def print_config_list() -> None:
    """Print all configured agents in a table format."""
    config = load_config()

    if not config.agents:
        console.print("[dim]No agents configured[/dim]")
        console.print("\n[dim]Run 'agentarts config' to configure an agent[/dim]")
        return

    table = Table(title=f"Agent Configurations ({get_config_file_path()})")
    table.add_column("Default", style="dim", width=8)
    table.add_column("Agent Name", style="cyan")
    table.add_column("Region", style="yellow")
    table.add_column("Entrypoint", style="green")
    table.add_column("Dependency File", style="blue")
    table.add_column("SWR Org", style="magenta")
    table.add_column("SWR Repo", style="blue")

    for name, agent_config in config.agents.items():
        is_default = "*" if name == config.default_agent else ""
        region = agent_config.base.region or "-"
        entrypoint = agent_config.base.entrypoint or "-"
        dependency_file = agent_config.base.dependency_file or "-"
        swr_org = agent_config.swr_config.organization or "-"
        swr_repo = agent_config.swr_config.repository or "-"
        table.add_row(is_default, name, region, entrypoint, dependency_file, swr_org, swr_repo)

    console.print(table)

    if config.default_agent:
        console.print(f"\n[dim]Default agent: [cyan]{config.default_agent}[/cyan][/dim]")


def print_agent_detail(name: str | None = None) -> bool:
    """
    Print detailed configuration for an agent.

    Args:
        name: Agent name (uses default if None)

    Returns:
        True if successful, False if agent not found
    """
    config = load_config()

    if name is None:
        name = config.default_agent

    if name is None:
        console.print("[red]Error: No agent specified and no default agent set[/red]")
        return False

    agent_config = config.get_agent(name)
    if agent_config is None:
        console.print(f"[red]Error: Agent '{name}' not found in configuration[/red]")
        return False

    import yaml

    console.print(f"\n[bold cyan]Agent: {name}[/bold cyan]")
    if name == config.default_agent:
        console.print("[dim](default)[/dim]")
    console.print()

    config_dict = agent_config.to_dict()
    yaml_str = yaml.dump(config_dict, default_flow_style=False, allow_unicode=True)
    console.print(yaml_str)

    return True


def set_config_value(key: str, value: str, agent_name: str | None = None) -> bool:
    """
    Set a configuration value for an agent.

    Args:
        key: Configuration key (supports dot notation, e.g., "base.region")
        value: Configuration value
        agent_name: Agent name (uses default if None)

    Returns:
        True if successful
    """
    config = load_config()

    if agent_name is None:
        agent_name = config.default_agent

    if agent_name is None:
        console.print("[red]Error: No agent specified and no default agent set[/red]")
        return False

    agent_config = config.get_agent(agent_name)
    if agent_config is None:
        console.print(f"[red]Error: Agent '{agent_name}' not found[/red]")
        return False

    keys = key.split(".")
    config_dict = agent_config.to_dict()

    current = config_dict
    for k in keys[:-1]:
        if k not in current:
            current[k] = {}
        current = current[k]

    current[keys[-1]] = value

    try:
        updated_config = AgentArtsConfig.from_dict(config_dict)

        if key == "base.name" and value != agent_name:
            config.agents[value] = updated_config
            del config.agents[agent_name]

            if config.default_agent == agent_name:
                config.default_agent = value

            console.print(f"[green]Done:[/green] Renamed agent [cyan]{agent_name}[/cyan] to [cyan]{value}[/cyan]")
            agent_name = value
        else:
            config.agents[agent_name] = updated_config

        if save_config(config):
            if key != "base.name":
                console.print(f"[green]Done:[/green] Set [cyan]{key}[/cyan] = [yellow]{value}[/yellow] for agent [cyan]{agent_name}[/cyan]")
            return True
    except Exception as e:
        console.print(f"[red]Error: Failed to set configuration: {e}[/red]")
        return False

    return False


def get_config_value(key: str, agent_name: str | None = None) -> bool:
    """
    Get a configuration value for an agent.

    Args:
        key: Configuration key (supports dot notation)
        agent_name: Agent name (uses default if None)

    Returns:
        True if successful, False if key not found
    """
    config = load_config()

    if agent_name is None:
        agent_name = config.default_agent

    if agent_name is None:
        console.print("[red]Error: No agent specified and no default agent set[/red]")
        return False

    agent_config = config.get_agent(agent_name)
    if agent_config is None:
        console.print(f"[red]Error: Agent '{agent_name}' not found[/red]")
        return False

    keys = key.split(".")
    config_dict = agent_config.to_dict()

    try:
        current = config_dict
        for k in keys:
            current = current[k]
        console.print(f"[cyan]{key}[/cyan] = [yellow]{current}[/yellow] (agent: {agent_name})")
        return True
    except (KeyError, TypeError):
        console.print(f"[red]Error: Key '{key}' not found in agent '{agent_name}'[/red]")
        return False


def set_env(key: str, value: str, agent_name: str | None = None) -> bool:
    """
    Set an environment variable for an agent.

    Args:
        key: Environment variable name
        value: Environment variable value
        agent_name: Agent name (uses default if None)

    Returns:
        True if successful
    """
    config = load_config()

    if agent_name is None:
        agent_name = config.default_agent

    if agent_name is None:
        console.print("[red]Error: No agent specified and no default agent set[/red]")
        return False

    agent_config = config.get_agent(agent_name)
    if agent_config is None:
        console.print(f"[red]Error: Agent '{agent_name}' not found[/red]")
        return False

    config_dict = agent_config.to_dict()
    env_vars: list[dict[str, str | None]] = config_dict.setdefault("runtime", {}).setdefault("environment_variables", [])

    for env_var in env_vars:
        if env_var.get("key") == key:
            env_var["value"] = value
            updated_config = AgentArtsConfig.from_dict(config_dict)
            config.agents[agent_name] = updated_config
            if save_config(config):
                console.print(f"[green]Done:[/green] Updated env [cyan]{key}[/cyan] for agent [cyan]{agent_name}[/cyan]")
                return True
            return False

    env_vars.append({"key": key, "value": value})
    updated_config = AgentArtsConfig.from_dict(config_dict)
    config.agents[agent_name] = updated_config
    if save_config(config):
        console.print(f"[green]Done:[/green] Added env [cyan]{key}[/cyan] for agent [cyan]{agent_name}[/cyan]")
        return True
    return False


def remove_env(key: str, agent_name: str | None = None) -> bool:
    """
    Remove an environment variable from an agent.

    Args:
        key: Environment variable name to remove
        agent_name: Agent name (uses default if None)

    Returns:
        True if successful
    """
    config = load_config()

    if agent_name is None:
        agent_name = config.default_agent

    if agent_name is None:
        console.print("[red]Error: No agent specified and no default agent set[/red]")
        return False

    agent_config = config.get_agent(agent_name)
    if agent_config is None:
        console.print(f"[red]Error: Agent '{agent_name}' not found[/red]")
        return False

    config_dict = agent_config.to_dict()
    env_vars: list[dict[str, str | None]] = config_dict.get("runtime", {}).get("environment_variables", [])

    original_len = len(env_vars)
    env_vars[:] = [e for e in env_vars if e.get("key") != key]

    if len(env_vars) == original_len:
        console.print(f"[red]Error: Environment variable '{key}' not found for agent '{agent_name}'[/red]")
        return False

    config_dict["runtime"]["environment_variables"] = env_vars
    updated_config = AgentArtsConfig.from_dict(config_dict)
    config.agents[agent_name] = updated_config
    if save_config(config):
        console.print(f"[green]Done:[/green] Removed env [cyan]{key}[/cyan] from agent [cyan]{agent_name}[/cyan]")
        return True
    return False


def list_env(agent_name: str | None = None) -> bool:
    """
    List environment variables for an agent.

    Args:
        agent_name: Agent name (uses default if None)

    Returns:
        True if successful
    """
    config = load_config()

    if agent_name is None:
        agent_name = config.default_agent

    if agent_name is None:
        console.print("[red]Error: No agent specified and no default agent set[/red]")
        return False

    agent_config = config.get_agent(agent_name)
    if agent_config is None:
        console.print(f"[red]Error: Agent '{agent_name}' not found[/red]")
        return False

    env_vars = agent_config.runtime.environment_variables or []

    if not env_vars:
        console.print(f"[dim]No environment variables configured for agent '{agent_name}'[/dim]")
        return True

    table = Table(title=f"Environment Variables ({agent_name})")
    table.add_column("Key", style="cyan")
    table.add_column("Value", style="yellow")

    for env_var in env_vars:
        display_value = env_var.value if env_var.value is not None else "[dim]<not set>[/dim]"
        table.add_row(env_var.key, display_value)

    console.print(table)
    return True


def generate_dockerfile(agent_name: str | None = None, output_path: str | None = None) -> bool:
    """
    Generate Dockerfile for an agent.

    Args:
        agent_name: Agent name (uses default if None)
        output_path: Output path for Dockerfile (default: ./Dockerfile)

    Returns:
        True if successful, False otherwise
    """
    from agentarts.toolkit.utils.runtime.container import (
        generate_dockerfile as _generate_dockerfile,
    )

    config = load_config()

    if agent_name is None:
        agent_name = config.default_agent

    if agent_name is None:
        console.print("[red]Error: No agent specified and no default agent set[/red]")
        return False

    agent_config = config.get_agent(agent_name)
    if agent_config is None:
        console.print(f"[red]Error: Agent '{agent_name}' not found[/red]")
        return False

    base_image = agent_config.base.base_image
    dependency_file = agent_config.base.dependency_file
    entrypoint = agent_config.base.entrypoint
    region = agent_config.base.region
    port = agent_config.runtime.invoke_config.port if agent_config.runtime.invoke_config else 8080

    return _generate_dockerfile(
        base_image=base_image,
        dependency_file=dependency_file,
        entrypoint=entrypoint,
        port=port,
        output_path=output_path or "Dockerfile",
        region=region,
    )
