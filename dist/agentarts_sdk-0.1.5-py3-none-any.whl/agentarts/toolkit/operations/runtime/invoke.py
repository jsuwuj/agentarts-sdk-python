"""Invoke operation implementation"""

import json
import logging
import os
import re
import uuid
from enum import Enum

from rich.console import Console

from agentarts.sdk.service.http_client import SignMode
from agentarts.sdk.service.runtime_client import LocalRuntimeClient, RuntimeClient
from agentarts.sdk.utils.constant import (
    _ensure_https,
    get_control_plane_endpoint,
    get_region,
    get_runtime_data_plane_endpoint,
)
from agentarts.toolkit.operations.runtime.config import (
    get_config_file_path,
    load_config,
)
from agentarts.toolkit.utils.common import echo_error, echo_info

console = Console()
logger = logging.getLogger(__name__)


def _validate_and_normalize_custom_path(custom_path: str | None) -> str | None:
    """
    Validate and normalize custom URL path.

    Rules:
    - Must not be empty string
    - Must not contain leading/trailing slashes (will be stripped)
    - Must be valid URL path segment (alphanumeric, hyphens, underscores, slashes for nested paths)
    - Must not contain special characters that could cause URL injection

    Args:
        custom_path: Raw custom path string from CLI

    Returns:
        Normalized custom path string, or None if not provided

    Raises:
        ValueError: If custom path contains invalid characters
    """
    if not custom_path:
        return None

    custom_path = custom_path.strip()

    if not custom_path:
        return None

    if custom_path.startswith("/"):
        custom_path = custom_path[1:]
    if custom_path.endswith("/"):
        custom_path = custom_path[:-1]

    if not custom_path:
        return None

    valid_pattern = r"^[a-zA-Z0-9_\-./]+$"
    if not re.match(valid_pattern, custom_path):
        msg = f"Invalid custom path '{custom_path}'. Only alphanumeric characters, hyphens, underscores, dots, and slashes are allowed."
        raise ValueError(msg)

    if ".." in custom_path:
        msg = f"Invalid custom path '{custom_path}'. Path traversal sequences ('..') are not allowed."
        raise ValueError(msg)

    return custom_path


def _resolve_agent_info(
    agent_name: str | None,
    region: str | None,
) -> tuple[str | None, str | None, str | None, str | None]:
    """
    Resolve agent name, region, agent_id and auth_type from config if not provided.

    Args:
        agent_name: Agent name (may be None)
        region: Region (may be None)

    Returns:
        Tuple of (agent_name, region, agent_id, auth_type) with resolved values.
        auth_type defaults to "IAM" when it cannot be resolved from the config
        (no config file, or the agent has no identity_configuration), so the
        data-plane commands sign with V11-HMAC-SHA256.
    """
    agent_id = None
    auth_type = None
    config_path = get_config_file_path()
    config = None
    if config_path.exists():
        config = load_config()

    if agent_name is None:
        if config:
            if config.default_agent and config.default_agent in (config.agents or {}):
                agent_name = config.default_agent
                agent_config = config.agents[agent_name]
                region = region or agent_config.base.region
                agent_id = agent_config.runtime.agent_id
                if agent_config.runtime.identity_configuration:
                    auth_type = agent_config.runtime.identity_configuration.authorizer_type
            elif config.agents:
                first_agent_key = next(iter(config.agents.keys()), None)
                if first_agent_key:
                    agent_name = first_agent_key
                    agent_config = config.agents[first_agent_key]
                    region = region or agent_config.base.region
                    agent_id = agent_config.runtime.agent_id
                    if agent_config.runtime.identity_configuration:
                        auth_type = agent_config.runtime.identity_configuration.authorizer_type
    elif config:
        if agent_name in (config.agents or {}):
            agent_config = config.agents[agent_name]
            region = region or agent_config.base.region
            agent_id = agent_config.runtime.agent_id
            if agent_config.runtime.identity_configuration:
                auth_type = agent_config.runtime.identity_configuration.authorizer_type
        else:
            logger.info("Agent '%s' not found in config, using default IAM authentication", agent_name)
            auth_type = "IAM"
    # Data-plane commands (start/stop session, invoke, exec-command, upload/download
    # files) sign exclusively with V11-HMAC-SHA256; the SDK-HMAC-SHA256 branch is
    # never used for signing. When auth_type can't be resolved from the config
    # (no .agentarts_config.yaml, or the agent has no identity_configuration),
    # default to "IAM" so these commands still sign with V11 instead of silently
    # sending an unsigned request that the IAM data-plane gateway rejects (401).
    return agent_name, region, agent_id, auth_type or "IAM"


def _check_file_transfer_enabled(
    agent_name: str,
    region: str,
    agent_id: str | None = None,
    verify_ssl: bool = True,
) -> None:
    """
    Check if file transfer is enabled for the agent.

    Args:
        agent_name: Agent name
        region: Huawei Cloud region
        agent_id: Optional agent ID from config file
        verify_ssl: SSL verification setting

    Raises:
        ValueError: If file transfer is not enabled for the agent
    """
    control_endpoint = get_control_plane_endpoint(region)
    control_client = RuntimeClient(control_endpoint=control_endpoint, verify_ssl=verify_ssl)

    agent_detail = None
    if agent_id:
        agent_detail = control_client.find_agent_by_id(agent_id)
    else:
        agent_info = control_client.find_agent_by_name(agent_name)
        if agent_info:
            agent_id = agent_info.get("id")
            if agent_id:
                agent_detail = control_client.find_agent_by_id(agent_id)

    if not agent_detail:
        raise ValueError(f"Agent '{agent_name}' not found")

    version_detail = agent_detail.get("version_detail") or {}
    invoke_config_resp = version_detail.get("invoke_config") or {}
    file_transfer_config = invoke_config_resp.get("file_transfer_config") or {}

    if not file_transfer_config.get("enabled", False):
        msg = (
            f"File transfer is not enabled for agent '{agent_name}'. "
            "To enable file transfer, please:\n"
            "  1. Set file_transfer_config.enabled=true in .agentarts_config.yaml\n"
            "  2. Create a new agent with 'agentarts deploy'"
        )
        raise ValueError(msg)


def _get_data_endpoint(
    agent_name: str,
    region: str,
    agent_id: str | None = None,
    verify_ssl: bool | str = True,
) -> str | None:
    """
    Get data plane endpoint for the agent.

    First checks if AGENTARTS_RUNTIME_DATA_ENDPOINT is configured.
    If not, fetches agent info from control plane and extracts access_endpoint.

    Args:
        agent_name: Agent name
        region: Huawei Cloud region
        agent_id: Optional agent ID from config file

    Returns:
        Data plane endpoint URL, or None if not available
    """
    data_endpoint = get_runtime_data_plane_endpoint()

    if not data_endpoint:
        control_endpoint = get_control_plane_endpoint(region)
        control_client = RuntimeClient(control_endpoint=control_endpoint, verify_ssl=verify_ssl)

        if agent_id:
            agent_detail = control_client.find_agent_by_id(agent_id)
            if agent_detail:
                version_detail = agent_detail.get("version_detail") or {}
                invoke_config_resp = version_detail.get("invoke_config") or {}
                access_endpoint = invoke_config_resp.get("access_endpoint")
                if access_endpoint:
                    data_endpoint = access_endpoint
        else:
            agent_info = control_client.find_agent_by_name(agent_name)
            if agent_info:
                agent_id = agent_info.get("id")
                if agent_id:
                    agent_detail = control_client.find_agent_by_id(agent_id)
                    if agent_detail:
                        version_detail = agent_detail.get("version_detail") or {}
                        invoke_config_resp = version_detail.get("invoke_config") or {}
                        access_endpoint = invoke_config_resp.get("access_endpoint")
                        if access_endpoint:
                            data_endpoint = access_endpoint

    if data_endpoint:
        data_endpoint = _ensure_https(data_endpoint)

    return data_endpoint


class InvokeMode(str, Enum):
    """Invoke mode."""

    LOCAL = "local"
    CLOUD = "cloud"


def _normalize_json_payload(payload: str) -> str:
    """
    Normalize JSON payload to handle Windows PowerShell quote stripping.

    On Windows PowerShell, double quotes inside single-quoted strings may be
    stripped when passed to subprocess, causing '{"message":"hello"}' to become
    '{message:hello}'. This function attempts to restore proper JSON formatting.

    Args:
        payload: Raw payload string received from CLI

    Returns:
        Normalized JSON string
    """
    if not payload:
        return payload

    payload = payload.strip()

    try:
        json.loads(payload)
        return payload
    except json.JSONDecodeError:
        pass

    if payload.startswith("'") and payload.endswith("'"):
        payload = payload[1:-1]

    if '\\"' in payload:
        payload = payload.replace('\\"', '"')
        try:
            json.loads(payload)
            return payload
        except json.JSONDecodeError:
            pass

    if payload.startswith("{") and payload.endswith("}"):
        inner = payload[1:-1].strip()
        if not inner:
            return "{}"

        result_parts = []
        parts = inner.split(",")
        for part in parts:
            part = part.strip()
            if ":" in part:
                key_val = part.split(":", 1)
                key = key_val[0].strip()
                val = key_val[1].strip() if len(key_val) > 1 else ""

                if not key.startswith('"') and not key.startswith("'"):
                    key = f'"{key}"'

                if val:
                    if not val.startswith('"') and not val.startswith("'") and not val.startswith("[") and not val.startswith("{") and not val.isdigit() and val.lower() not in ("true", "false", "null"):
                        val = f'"{val}"'

                result_parts.append(f"{key}:{val}")
            else:
                result_parts.append(part)

        reconstructed = "{" + ",".join(result_parts) + "}"
        try:
            json.loads(reconstructed)
            return reconstructed
        except json.JSONDecodeError:
            pass

    return payload


def invoke_agent(
    payload: str,
    agent_name: str | None = None,
    mode: InvokeMode = InvokeMode.CLOUD,
    region: str | None = None,
    port: int | None = None,
    endpoint: str | None = None,
    session_id: str | None = None,
    bearer_token: str | None = None,
    timeout: int = 900,
    skip_ssl_verification: bool = False,
    user_id: str | None = None,
    custom_path: str | None = None,
) -> bool:
    """
    Invoke agent locally or on cloud.

    Args:
        payload: JSON payload string
        agent_name: Agent name (for cloud mode, uses default if None)
        mode: Invoke mode (local or cloud)
        region: Huawei Cloud region (for cloud mode)
        port: Local port (for local mode)
        endpoint: Optional endpoint name
        session_id: Session ID for stateful agents
        bearer_token: Optional bearer token
        timeout: Request timeout in seconds
        skip_ssl_verification: Skip SSL certificate verification
        user_id: Optional user ID for OAuth2 outbound credentials
        custom_path: Optional custom path appended to /invocations path

    Returns:
        True if successful, False otherwise
    """
    normalized_custom_path = _validate_and_normalize_custom_path(custom_path)
    normalized_payload = _normalize_json_payload(payload)
    try:
        json.loads(normalized_payload)
    except json.JSONDecodeError:
        echo_error("Payload must be valid JSON")
        console.print()
        console.print("[yellow]Usage Tips:[/yellow]")
        console.print("  1. Use [cyan]single quotes[/cyan] to wrap JSON payload")
        console.print("  2. Use [cyan]compact JSON format[/cyan] (no spaces after colon/comma)")
        console.print()
        console.print("[green]✓ Correct Examples:[/green]")
        console.print('  [white]agentarts invoke \'{"message":"hello world"}\'[white]')
        console.print('  [white]agentarts invoke \'{"name":"test","message":"hello world"}\'[white]')
        console.print()
        console.print("[red]✗ Common Mistakes:[/red]")
        console.print("  [dim]Spaces after colon/comma will cause parsing issues in PowerShell:[/dim]")
        console.print('  [dim]agentarts invoke \'{"message": "hello world"}\'[/dim]')
        console.print()
        console.print("[yellow]Alternative for complex JSON:[/yellow]")
        console.print("  Use [cyan]--%[/cyan] stop-parsing symbol in PowerShell:")
        console.print('  [white]agentarts --% invoke \'{"message": "hello world"}\'[white]')
        return False

    actual_bearer_token = bearer_token or os.environ.get("BEARER_TOKEN")

    try:
        if mode == InvokeMode.LOCAL:
            local_port = port or 8080
            client = LocalRuntimeClient(port=local_port)

            console.print()
            echo_info("Invoke Request", f"[cyan]Mode:[/cyan] [yellow]Local[/yellow]\n[cyan]Endpoint:[/cyan] [white]localhost:{local_port}[/white]")

            result = client.invoke_agent(
                payload=normalized_payload,
                session_id=session_id,
                bearer_token=actual_bearer_token,
                endpoint=endpoint,
                timeout=timeout,
                user_id=user_id,
                custom_path=normalized_custom_path,
            )
        else:
            agent_name, region, agent_id, auth_type = _resolve_agent_info(agent_name, region)

            if agent_name is None:
                echo_error("No agent specified and no default agent configured")
                console.print("[dim]Specify --agent or set a default agent in config[/dim]")
                return False

            actual_region = region or get_region()
            actual_session_id = session_id or str(uuid.uuid4())
            verify_ssl = not skip_ssl_verification

            data_endpoint = _get_data_endpoint(agent_name, actual_region, agent_id, verify_ssl)

            if not data_endpoint:
                echo_error(f"No data plane endpoint configured and could not get access_endpoint from agent [yellow]{agent_name} {actual_region}[/yellow]")
                console.print("[dim]Set AGENTARTS_RUNTIME_DATA_ENDPOINT environment variable or ensure agent is deployed[/dim]")
                return False

            sign_mode = SignMode.SDK_HMAC_SHA256
            if auth_type and auth_type.upper() == "IAM":
                sign_mode = SignMode.V11_HMAC_SHA256
            elif not actual_bearer_token:
                echo_error("Bearer token is required for non-IAM authentication")
                console.print("[dim]Specify --bearer-token or set BEARER_TOKEN environment variable[/dim]")
                return False

            echo_info("Invoke Request", f"[cyan]Mode:[/cyan] [yellow]Cloud[/yellow]\n[cyan]Agent:[/cyan] [white]{agent_name}[/white]\n[cyan]Session:[/cyan] [dim]{actual_session_id}[/dim]\n[cyan]Endpoint:[/cyan] [dim]{data_endpoint}[/dim]\n[cyan]Auth Type:[/cyan] [dim]{auth_type or 'None'}[/dim]")

            client = RuntimeClient(
                data_endpoint=data_endpoint,
                verify_ssl=verify_ssl,
                sign_mode=sign_mode,
                region_id=actual_region,
            )

            result = client.invoke_agent(
                agent_name=agent_name,
                session_id=actual_session_id,
                payload=normalized_payload,
                bearer_token=actual_bearer_token,
                endpoint=endpoint,
                timeout=timeout,
                user_id=user_id,
                custom_path=normalized_custom_path,
            )

        if isinstance(result, dict):
            if "error" in result:
                echo_error(str(result.get("error")))
                return False

            console.print()
            console.print("[bold green]Response:[/bold green]")
            console.print_json(json.dumps(result, indent=2, ensure_ascii=False))
            return True
        console.print()
        console.print("[bold green]Streaming Response:[/bold green]")
        for event in result:
            console.print(f"[dim]{event}[/dim]")
        return True

    except RuntimeError as e:
        echo_error(str(e))
        return False
    except Exception as e:
        echo_error(str(e))
        return False
